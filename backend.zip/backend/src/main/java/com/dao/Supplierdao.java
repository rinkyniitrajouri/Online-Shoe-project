package com.dao;
import com.model.Supplier;
public interface Supplierdao {

	public void insertSupplier(Supplier supplier);
	public void update(Supplier supplier);
}
