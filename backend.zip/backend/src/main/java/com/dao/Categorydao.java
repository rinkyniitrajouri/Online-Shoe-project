package com.dao;

import com.model.Category;
public interface Categorydao {

	public void insertCategory(Category category);
}
