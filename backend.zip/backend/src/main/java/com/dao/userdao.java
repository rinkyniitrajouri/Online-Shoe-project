package com.dao;

import com.model.User;

public interface userdao {
	
public void insertUser(User user);
	
}

