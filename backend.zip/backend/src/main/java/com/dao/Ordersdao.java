package com.dao;

import com.model.Orders;

public interface Ordersdao {

	public void insert(Orders order);
}
