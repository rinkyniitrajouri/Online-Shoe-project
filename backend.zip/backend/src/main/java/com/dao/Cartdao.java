package com.dao;

import com.model.Cart;

public interface Cartdao {

	public void insert(Cart cart);
}
